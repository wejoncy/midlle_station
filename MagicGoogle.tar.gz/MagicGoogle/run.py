# -*- coding:utf-8 -*-
from MagicGoogle import MagicGoogle
mg = MagicGoogle()

fp=open('all_c_ok.txt')
kws=fp.readlines()
fp.close()
fpw=open('url1.txt','a')
url_index=0
kws.reverse()
for kw in kws:
    print('parse %d kw' % url_index)
    url_index+=1
    for url in mg.search_url(query=kw,num=100):
        fpw.writelines( url)
        fpw.writelines('\n')

fpw.close()
