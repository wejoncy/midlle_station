from .magic_google import MagicGoogle
